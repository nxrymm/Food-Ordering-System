
package com.mycompany.comprogfinals;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.print.*;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class FoodOrderingSystem {

    private JFrame frame;
    private JPanel frontPagePanel;
    private JPanel orderingPanel;
    private JPanel orderFormPanel;
    private JTextArea orderSummaryArea;
    private JTextField totalField;
    private JTextField nameField;
    private JTextField contactField;
    private JTextField addressField;

    private String[] foodItems = {"Egg Drop", "Dumplings", "Hotsilog", "Tapsilog", "Takoyaki", "Tonkatsu", "Burger & Butter", "Chick Fil A.", "Egg Avocado Toast", "French Toast"};
    private double[] foodPrices = {100.00, 100.00, 100.00, 100.00, 100.00, 100.00, 100.00, 100.00, 100.00, 100.00};
    private String[] foodImages = {"assets/food1.jpg", "assets/food2.jpg", "assets/food3.jpg", "assets/food4.jpg", "assets/food5.jpg", "assets/food6.jpg", "assets/food7.jpg", "assets/food8.jpg", "assets/food9.jpg", "assets/food10.jpg"};
    private JSpinner[] foodSpinners;

    private String[] drinkItems = {"Apple Juice", "Blue Pea Milkshake", "Blueberry Soda", "Caramel Lotus Frappe", "Grape Juice", "Hojicha Latte", "Iced Tomato", "Lemon Juice", "Pink Apple Pudding", "Rose Coffee"};
    private double[] drinkPrices = {50.00, 50.00, 50.00, 50.00, 50.00, 50.00, 50.00, 50.00, 50.00, 50.00};
    private String[] drinkImages = {"assets/drinks1.jpg", "assets/drinks2.jpg", "assets/drinks3.jpg", "assets/drinks4.jpg", "assets/drinks5.jpg", "assets/drinks6.jpg", "assets/drinks7.jpg", "assets/drinks8.jpg", "assets/drinks9.jpg", "assets/drinks10.jpg"};
    private JSpinner[] drinkSpinners;

    private String[] dessertItems = {"Cherry Ice Cream", "Cherry On Top Cupcake", "Chocolate Cake", "Chocolate Chip Cookies", "Ice Cream Waffle", "Lemon Squeeze Cake", "Macaroon", "Strawberry Cake", "Strawberry Chocolate Cake", "Strawberry Donut"};
    private double[] dessertPrices = {80.00, 100.00, 80.00, 100.00, 80.00, 100.00, 80.00, 100.00, 80.00, 100.00};
    private String[] dessertImages = {"assets/dessert1.jpg", "assets/dessert2.jpg", "assets/dessert3.jpg", "assets/dessert4.jpg", "assets/dessert5.jpg", "assets/dessert6.jpg", "assets/dessert7.jpg", "assets/dessert8.jpg", "assets/dessert9.jpg", "assets/dessert10.jpg"};
    private JSpinner[] dessertSpinners;

    private List<OrderItem> orderItems = new ArrayList<>();

    private JPanel foodsPanel;
    private JPanel drinksPanel;
    private JPanel dessertsPanel;

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> {
            try {
                FoodOrderingSystem window = new FoodOrderingSystem();
                window.frame.setVisible(true);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
    }

    public FoodOrderingSystem() {
        initialize();
    }

    private void initialize() {
        frame = new JFrame("WakeyBakey!");
        frame.setSize(1100, 800); 
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().setLayout(new BorderLayout());

        createFrontPagePanel();
        createOrderingPanel();
        createOrderFormPanel();

        frame.add(frontPagePanel, BorderLayout.CENTER);
        frame.setLocationRelativeTo(null); 

        frame.setResizable(true); 
    }

    private void createFrontPagePanel() {
        frontPagePanel = new JPanel(new BorderLayout());
        frontPagePanel.setBackground(new Color(240, 255, 240));
        
        JLabel logoLabel = new JLabel(new ImageIcon("assets/logo1.png"), SwingConstants.CENTER); 
        frontPagePanel.add(logoLabel, BorderLayout.CENTER);

        JButton nextButton = new JButton("ORDER NOW");
        nextButton.setFont(new Font("Tahoma", Font.PLAIN, 18));
        nextButton.setBackground(new Color(255, 105, 180));
        nextButton.setForeground(Color.WHITE);
        nextButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switchToPanel(orderingPanel);
            }
        });
        frontPagePanel.add(nextButton, BorderLayout.SOUTH);
    }

    private void createOrderingPanel() {
        orderingPanel = new JPanel(new BorderLayout(10, 10)); 

     
        foodsPanel = createItemPanel(foodItems, foodPrices, foodImages, "Foods");
        drinksPanel = createItemPanel(drinkItems, drinkPrices, drinkImages, "Drinks");
        dessertsPanel = createItemPanel(dessertItems, dessertPrices, dessertImages, "Desserts");

        JButton foodsButton = new JButton("Foods");
        foodsButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        foodsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switchToCategoryPanel(foodsPanel);
            }
        });

        JButton drinksButton = new JButton("Drinks");
        drinksButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        drinksButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switchToCategoryPanel(drinksPanel);
            }
        });

        JButton dessertsButton = new JButton("Desserts");
        dessertsButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        dessertsButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switchToCategoryPanel(dessertsPanel);
            }
        });

     
        JPanel categoryButtonsPanel = new JPanel(new GridLayout(1, 3, 10, 10));
        categoryButtonsPanel.add(foodsButton);
        categoryButtonsPanel.add(drinksButton);
        categoryButtonsPanel.add(dessertsButton);

       
        JPanel leftPanel = new JPanel(new BorderLayout(10, 10));
        leftPanel.add(categoryButtonsPanel, BorderLayout.NORTH);
        leftPanel.add(foodsPanel, BorderLayout.CENTER); 

 
        orderingPanel.add(leftPanel, BorderLayout.CENTER);

  
        orderSummaryArea = new JTextArea(15, 30);
        orderSummaryArea.setEditable(false);
        orderSummaryArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        orderSummaryArea.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        JScrollPane scrollPane = new JScrollPane(orderSummaryArea);
        scrollPane.setPreferredSize(new Dimension(300, 200)); 
        JPanel summaryPanel = new JPanel(new BorderLayout());
        summaryPanel.setBorder(BorderFactory.createTitledBorder("Current Order"));
        summaryPanel.add(scrollPane, BorderLayout.CENTER);

       
        JButton clearAllButton = new JButton("CLEAR ALL");
        clearAllButton.setFont(new Font("Tahoma", Font.PLAIN, 14));
        clearAllButton.setBackground(new Color(156, 34, 93));
        clearAllButton.setForeground(Color.WHITE);
        clearAllButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                clearAllOrders();
            }
        });
        summaryPanel.add(clearAllButton, BorderLayout.SOUTH);

        orderingPanel.add(summaryPanel, BorderLayout.EAST);

        
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        totalField = new JTextField(10);
        totalField.setEditable(false);
        totalField.setFont(new Font("Monospaced", Font.BOLD, 14));
        bottomPanel.add(new JLabel("Total: "));
        bottomPanel.add(totalField);

        JButton orderButton = new JButton("PLACE ORDER");
        orderButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        orderButton.setBackground(new Color(255, 105, 180));
        orderButton.setForeground(Color.WHITE);
        orderButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                switchToPanel(orderFormPanel);
            }
        });
        bottomPanel.add(orderButton);

        orderingPanel.add(bottomPanel, BorderLayout.SOUTH);
    }

    private void styleCategoryButton(JButton button) {
        button.setFont(new Font("Tahoma", Font.PLAIN, 16));
        button.setBackground(new Color(70, 130, 180));
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        button.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                button.setBackground(new Color(100, 149, 237));
            }
        });
    }

    private JPanel createItemPanel(String[] items, double[] prices, String[] images, String type) {
    JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));
    GridBagConstraints gbc = new GridBagConstraints();
    gbc.insets = new Insets(10, 10, 10, 10);
    gbc.anchor = GridBagConstraints.WEST;

    JSpinner[] spinners = new JSpinner[items.length];

    for (int i = 0; i < items.length; i++) {
        gbc.gridx = 0;
        gbc.gridy = i;

        JPanel itemPanel = new JPanel(new BorderLayout());
        itemPanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
        itemPanel.setBackground(Color.WHITE);
        itemPanel.setPreferredSize(new Dimension(300, 150));

        // Adjust the size of the image
        ImageIcon originalIcon = new ImageIcon(images[i]);
        Image originalImage = originalIcon.getImage();
        Image resizedImage = originalImage.getScaledInstance(100, 100, Image.SCALE_SMOOTH); 
        ImageIcon resizedIcon = new ImageIcon(resizedImage);

        JLabel imageLabel = new JLabel(resizedIcon);
        imageLabel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        itemPanel.add(imageLabel, BorderLayout.WEST);

        JPanel detailsPanel = new JPanel(new GridLayout(3, 1, 5, 5));
        detailsPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        detailsPanel.setBackground(Color.WHITE);

        JLabel nameLabel = new JLabel(items[i]);
        nameLabel.setFont(new Font("Tahoma", Font.BOLD, 14));
        detailsPanel.add(nameLabel);

        JLabel priceLabel = new JLabel(String.format("Price: PHP %.2f", prices[i]));
        priceLabel.setFont(new Font("Tahoma", Font.PLAIN, 12));
        detailsPanel.add(priceLabel);

        JPanel spinnerPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 5));
        spinnerPanel.setBackground(Color.WHITE);

        spinners[i] = new JSpinner(new SpinnerNumberModel(0, 0, 50, 1));
        spinners[i].setPreferredSize(new Dimension(50, 25));
        spinners[i].addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                updateOrderSummary();
            }
        });

        spinnerPanel.add(new JLabel("Qty: "));
        spinnerPanel.add(spinners[i]);

        detailsPanel.add(spinnerPanel);
        itemPanel.add(detailsPanel, BorderLayout.CENTER);

        panel.add(itemPanel, gbc);
    }

    if (type.equals("Foods")) {
        foodSpinners = spinners;
    } else if (type.equals("Drinks")) {
        drinkSpinners = spinners;
    } else if (type.equals("Desserts")) {
        dessertSpinners = spinners;
    }

    return panel;
}

    private void createOrderFormPanel() {
        orderFormPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel formTitleLabel = new JLabel("ORDER FORM");
        formTitleLabel.setFont(new Font("Tahoma", Font.BOLD, 24));
        formTitleLabel.setForeground(new Color(50, 205, 50));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        orderFormPanel.add(formTitleLabel, gbc);

        gbc.gridwidth = 1;
        gbc.gridx = 0;
        gbc.gridy = 1;
        orderFormPanel.add(new JLabel("NAME: "), gbc);
        gbc.gridx = 1;
        nameField = new JTextField(20);
        orderFormPanel.add(nameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        orderFormPanel.add(new JLabel("CONTACT NO.: "), gbc);

        gbc.gridx = 1;
        contactField = new JTextField(20);
        orderFormPanel.add(contactField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        orderFormPanel.add(new JLabel("ADDRESS: "), gbc);

        gbc.gridx = 1;
        addressField = new JTextField(20);
        orderFormPanel.add(addressField, gbc);

        JButton backButton = new JButton("BACK");

        backButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        backButton.setBackground(new Color(255, 69, 0));

        backButton.setForeground(Color.WHITE);
        backButton.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                switchToPanel(orderingPanel);
            }
        });

        JButton submitButton = new JButton("SUBMIT ORDER");
        submitButton.setFont(new Font("Tahoma", Font.PLAIN, 16));
        submitButton.setBackground(new Color(50, 205, 50));
        submitButton.setForeground(Color.WHITE);
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitButton.addActionListener(new ActionListener() {

                    @Override
                    public void actionPerformed(ActionEvent e) {
                        placeOrder(); 
                    }
                });
            }
        });

        JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        buttonPanel.add(backButton);
        buttonPanel.add(submitButton);

        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.gridwidth = 2;
        orderFormPanel.add(buttonPanel, gbc);
    }


    private void switchToPanel(JPanel panel) {
        frame.getContentPane().removeAll();
        frame.getContentPane().add(panel);
        frame.revalidate();
        frame.repaint();
    }

    private void switchToCategoryPanel(JPanel panel) {
        JPanel leftPanel = (JPanel) orderingPanel.getComponent(0);
        leftPanel.remove(1); 
        leftPanel.add(panel, BorderLayout.CENTER);
        orderingPanel.revalidate();
        orderingPanel.repaint();
    }

    private void updateOrderSummary() {
        orderSummaryArea.setText("");
        orderItems.clear();
        double total = 0;

     
        for (int i = 0; i < foodItems.length; i++) {
            int qty = (int) foodSpinners[i].getValue();
            if (qty > 0) {
                double price = qty * foodPrices[i];
                orderItems.add(new OrderItem(foodItems[i], qty, price));
                orderSummaryArea.append(String.format("%s x%d - PHP %.2f\n", foodItems[i], qty, price));
                total += price;
            }
        }


        for (int i = 0; i < drinkItems.length; i++) {
            int qty = (int) drinkSpinners[i].getValue();
            if (qty > 0) {
                double price = qty * drinkPrices[i];
                orderItems.add(new OrderItem(drinkItems[i], qty, price));
                orderSummaryArea.append(String.format("%s x%d - PHP %.2f\n", drinkItems[i], qty, price));
                total += price;
            }
        }


        for (int i = 0; i < dessertItems.length; i++) {
            int qty = (int) dessertSpinners[i].getValue();
            if (qty > 0) {
                double price = qty * dessertPrices[i];
                orderItems.add(new OrderItem(dessertItems[i], qty, price));
                orderSummaryArea.append(String.format("%s x%d - PHP %.2f\n", dessertItems[i], qty, price));
                total += price;
            }
        }

        totalField.setText(String.format("PHP %.2f", total));
    }

    private void clearAllOrders() {
        for (JSpinner spinner : foodSpinners) {
            spinner.setValue(0);
        }
        for (JSpinner spinner : drinkSpinners) {
            spinner.setValue(0);
        }
        for (JSpinner spinner : dessertSpinners) {
            spinner.setValue(0);
        }
        updateOrderSummary();
    }

    private void placeOrder() {
        String name = nameField.getText().trim();
        String contact = contactField.getText().trim();
        String address = addressField.getText().trim();

        if (name.isEmpty() || contact.isEmpty() || address.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please fill out all fields.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (orderItems.isEmpty()) {
            JOptionPane.showMessageDialog(frame, "Please add at least one item to your order.", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        StringBuilder orderDetails = new StringBuilder();
        orderDetails.append("Name: ").append(name).append("\n");
        orderDetails.append("Contact: ").append(contact).append("\n");
        orderDetails.append("Address: ").append(address).append("\n");
        orderDetails.append("Order Summary:\n");
        for (OrderItem item : orderItems) {
            orderDetails.append(String.format("%s x%d - PHP %.2f\n", item.getName(), item.getQuantity(), item.getPrice()));
        }
        orderDetails.append("Total: ").append(totalField.getText()).append("\n");

  
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String receipt = generateReceipt(name, contact, address, orderDetails.toString(), dateFormat.format(new Date()));

        JOptionPane.showMessageDialog(frame, "Order placed successfully!\n\n" + receipt, "Success", JOptionPane.INFORMATION_MESSAGE);
        clearAllOrders();
        switchToPanel(frontPagePanel);


        printOrder(receipt);
    }

    private String generateReceipt(String name, String contact, String address, String orderDetails, String currentDate) {
        StringBuilder receiptBuilder = new StringBuilder();
        receiptBuilder.append("============ Receipt ============\n");
        receiptBuilder.append("Date: ").append(currentDate).append("\n\n");
        receiptBuilder.append("Customer Information:\n");
        receiptBuilder.append("Name: ").append(name).append("\n");
        receiptBuilder.append("Contact: ").append(contact).append("\n");
        receiptBuilder.append("Address: ").append(address).append("\n\n");
        receiptBuilder.append("Order Details:\n");
        receiptBuilder.append(orderDetails);
        receiptBuilder.append("=================================\n");
        return receiptBuilder.toString();
    }

    private void printOrder(String orderDetails) {
        PrinterJob job = PrinterJob.getPrinterJob();
        job.setPrintable(new Printable() {
            @Override
            public int print(Graphics g, PageFormat pf, int page) throws PrinterException {
                if (page > 0) {
                    return NO_SUCH_PAGE;
                }

                Graphics2D g2d = (Graphics2D) g;
                g2d.translate(pf.getImageableX(), pf.getImageableY());

                String[] lines = orderDetails.split("\n");
                int y = 0;
                for (String line : lines) {
                    y += g.getFontMetrics().getHeight();
                    g.drawString(line, 0, y);
                }

                return PAGE_EXISTS;
            }
        });

        boolean doPrint = job.printDialog();
        if (doPrint) {
            try {
                job.print();
            } catch (PrinterException ex) {
                ex.printStackTrace();
            }
        }
    }

    private static class OrderItem {
        private String name;
        private int quantity;
        private double price;

        public OrderItem(String name, int quantity, double price) {
            this.name = name;
            this.quantity = quantity;
            this.price = price;
        }

        public String getName() {
            return name;
        }

        public int getQuantity() {
            return quantity;
        }

        public double getPrice() {
            return price;
        }
    }
}